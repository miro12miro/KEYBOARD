# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
# You should have received a copy of the License along with this program.
#################################################################################
{
    'name': 'POS Keyboard Shortcuts',
    'version': '1.0',
    'category': 'Point of Sale',
    'summary': 'POS Keyboard Shortcuts',
    'description': """
This module is used to handle point of sale features with keyboard shortcuts.
""",
    'price': 25,
    'currency': 'EUR',
    'author': "Acespritech Solutions Pvt. Ltd.",
    'website': "http://www.acespritech.com",
    'depends': ['web', 'point_of_sale', 'base','account'],
    'data': [
        'views/aces_pos_keyboard.xml',
        'views/account_view.xml',
        'views/res_company.xml',
    ],
    'demo': [],
    'test': [],
    'images': ['static/description/main_screenshot.png'],
    'qweb': ['static/src/xml/pos.xml'],
    'installable': True,
    'auto_install': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
