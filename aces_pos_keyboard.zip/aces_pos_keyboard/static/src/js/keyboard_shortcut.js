odoo.define('aces_pos_keyboard.keyboard', function (require) {
	"use strict";

	var models = require('point_of_sale.models');
	var screens = require('point_of_sale.screens');

	models.load_fields("account.journal", ['shortcut_key']);
    models.load_fields("res.company", ['pos_price', 'pos_quantity', 'pos_discount', 'pos_search', 'pos_next']);

    screens.ScreenWidget.include({
    	init: function(parent,options){
			var self = this;
	        this._super(parent,options);
	        this.keydown_shortcut = function(event){
	        	event.stopImmediatePropagation();
	        	self.keyboard_shortcuts(event);
			};
	    },
    	start: function(){
			var self = this;
			this._super();
			if(self.pos.config.enable_keyboard_shortcut){
				$(document).keydown(_.bind(this.keydown_shortcut, self));
			}
		},
		keyboard_shortcuts: function(event){
			var self = this;
			if($(event.target).is(':input')){
				return
			}
			var order = this.pos.get_order();
			var current_screen = self.gui.get_current_screen();
			var keytostring = event.key;
			// Company Setting
			var qty = self.pos.company.pos_quantity || '';
            var search = self.pos.company.pos_search || '';
            var discount = self.pos.company.pos_discount || '';
	        var price = self.pos.company.pos_price || '';
	        var next_order = self.pos.company.pos_next || '';

	        // keyboard Shortcuts
	        if(current_screen === "products"){
	        	// focus on product search box (Working)
				if(keytostring === search){
					self.pos.gui.screen_instances.products.el.querySelector('.searchbox input').focus();
					event.preventDefault();
				}
	        	if(order.get_selected_orderline()){
			        // select QTY Mode of numpad
					if(keytostring === qty){
						$(self.pos.gui.screen_instances.products.numpad.el).find("button[data-mode='quantity']").trigger('click');
					}
					// select Disc Mode of numpad
					if(keytostring === discount){
						$(self.pos.gui.screen_instances.products.numpad.el).find("button[data-mode='discount']").trigger('click');
					}
					// select Price Mode of numpad
					if(keytostring === price){
						$(self.pos.gui.screen_instances.products.numpad.el).find("button[data-mode='price']").trigger('click');
					}
					// Trigger Numpad Numeric Click
					if($.isNumeric(keytostring) || keytostring === '.' || keytostring === ','){
						if(keytostring === ',') keytostring = '.'
						$(self.pos.gui.screen_instances.products.numpad.el).find(".number-char:contains("+ keytostring +")").click();
					}
					// BackSpace of Numpad
					if(event.keyCode === $.ui.keyCode.BACKSPACE){
						$(self.pos.gui.screen_instances.products.numpad.el).find(".input-button.numpad-backspace").trigger('click');
					}
	        	}
	        } 
	        else if(current_screen === "receipt"){
	        	if(keytostring === next_order){
	        		self.pos.gui.screen_instances.receipt.click_next();
	        	}
	        }
		},
    });
    screens.PaymentScreenWidget.include({
    	init: function(parent, options) {
            var self = this;
            this._super(parent, options);
            this.keyboard_shortcut = function(event){
            	if(self.gui.get_current_screen() === "payment"){
	            	var keytostring = event.key;
	            	var selected_payment_method = _.find(self.pos.cashregisters, function(cashregister){
		        		return cashregister.journal.shortcut_key === keytostring;
		        	})
		        	if(selected_payment_method){
		        		self.click_paymentmethods(selected_payment_method.journal_id[0]);
		        	}
            	}
            	event.stopImmediatePropagation();
            };
    	},
    	show: function(){
    		var self = this;
    		this._super();
    		if(self.pos.config.enable_keyboard_shortcut){
    			$(document).keypress(_.bind(this.keyboard_shortcut, self));
    		}
    	},
    })
});